
import { useEffect, useRef, useState } from 'react';
import cornerstone from 'cornerstone-core';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { downloadDicom } from '@/services/DicomService';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';
import { Link } from 'react-router-dom';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Download, ZoomIn } from 'lucide-react';

interface DicomViewerProps {
  fileUrl: string;
  fileId: string;
  fileName: string;
}

const DicomViewer = ({ fileUrl, fileId, fileName }: DicomViewerProps) => {
  const viewportRef = useRef<HTMLDivElement>(null);
  const [windowWidth, setWindowWidth] = useState(400);
  const [windowCenter, setWindowCenter] = useState(40);
  const [zoom, setZoom] = useState(1);
  const [initialized, setInitialized] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const { user } = useAuth();

  // Inicializar y cargar la imagen
  useEffect(() => {
    if (!viewportRef.current) return;

    const element = viewportRef.current;
    setLoadError(false);
    
    try {
      // Asegurar que el elemento esté limpio antes de habilitar
      try {
        cornerstone.disable(element);
      } catch (e) {
        // Ignorar errores si el elemento no estaba habilitado previamente
      }

      // Habilitar el elemento para cornerstone
      cornerstone.enable(element);
      
      console.log('Cargando imagen DICOM desde URL:', fileUrl);
      
      // Cargar la imagen
      cornerstone.loadImage(`wadouri:${fileUrl}`).then(image => {
        console.log('Imagen DICOM cargada correctamente:', image);
        
        // Mostrar la imagen en el viewport
        cornerstone.displayImage(element, image);
        setInitialized(true);
        
        // Ajustar el tamaño de la ventana inicialmente
        const viewport = cornerstone.getViewport(element);
        setWindowWidth(viewport.voi.windowWidth || 400);
        setWindowCenter(viewport.voi.windowCenter || 40);
        
        // Notificar al usuario
        toast.success('Imagen DICOM cargada correctamente');
      }, error => {
        console.error('Error al cargar la imagen DICOM:', error);
        setLoadError(true);
        toast.error('Error al cargar la imagen DICOM');
      });
    } catch (error) {
      console.error('Error en cornerstone:', error);
      setLoadError(true);
      toast.error('Error al inicializar el visor DICOM');
    }

    // Limpieza
    return () => {
      try {
        if (element) {
          cornerstone.disable(element);
        }
      } catch (error) {
        console.error('Error al limpiar cornerstone:', error);
      }
    };
  }, [fileUrl]);

  // Actualizar la ventana y nivel
  useEffect(() => {
    if (!initialized || !viewportRef.current) return;
    
    try {
      const element = viewportRef.current;
      const viewport = cornerstone.getViewport(element);
      
      viewport.voi.windowWidth = windowWidth;
      viewport.voi.windowCenter = windowCenter;
      cornerstone.setViewport(element, viewport);
    } catch (error) {
      console.error('Error al ajustar ventana/nivel:', error);
    }
  }, [windowWidth, windowCenter, initialized]);

  // Actualizar el zoom
  useEffect(() => {
    if (!initialized || !viewportRef.current) return;
    
    try {
      const element = viewportRef.current;
      const viewport = cornerstone.getViewport(element);
      
      viewport.scale = zoom;
      cornerstone.setViewport(element, viewport);
    } catch (error) {
      console.error('Error al ajustar zoom:', error);
    }
  }, [zoom, initialized]);

  // Manejar las descargas
  const handleDownload = (format: 'dicom' | 'zip') => {
    try {
      downloadDicom(fileId, format);
      toast.success(`Descargando ${fileName} en formato ${format === 'dicom' ? 'DICOM' : 'ZIP'}`);
    } catch (error) {
      toast.error('Error al descargar el archivo');
      console.error('Error al descargar:', error);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">{fileName}</CardTitle>
      </CardHeader>
      
      <CardContent>
        <div className="dicom-container rounded-md overflow-hidden border" style={{ height: '400px', width: '100%' }}>
          <div ref={viewportRef} className="dicom-viewport" style={{ height: '100%', width: '100%', background: '#000' }}>
            {loadError && (
              <div className="flex items-center justify-center h-full text-white bg-gray-900">
                <p>Error al cargar la imagen DICOM</p>
              </div>
            )}
          </div>
        </div>
        
        {initialized && user?.role === "doctor" && (
          <div className="mt-4 space-y-4">
            <div>
              <label className="text-sm font-medium">Brillo (Centro de ventana): {windowCenter}</label>
              <Slider 
                value={[windowCenter]} 
                min={-1024} 
                max={1024} 
                step={1}
                onValueChange={(values) => setWindowCenter(values[0])} 
              />
            </div>

            <div>
              <label className="text-sm font-medium">Contraste (Ancho de ventana): {windowWidth}</label>
              <Slider 
                value={[windowWidth]} 
                min={1} 
                max={2048} 
                step={1} 
                onValueChange={(values) => setWindowWidth(values[0])} 
              />
            </div>

            <div>
              <label className="text-sm font-medium">Zoom: {zoom.toFixed(2)}x</label>
              <Slider 
                value={[zoom]} 
                min={0.25} 
                max={5} 
                step={0.1} 
                onValueChange={(values) => setZoom(values[0])} 
              />
            </div>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-end gap-2">
        <Link 
          to={`/viewer/${fileId}`}
          state={{ fileUrl, fileName }}
          className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-secondary text-secondary-foreground hover:bg-secondary/80 h-10 px-4 py-2"
        >
          <ZoomIn className="mr-2 h-4 w-4" />
          Visualizar a detalle
        </Link>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button>
              <Download className="mr-2 h-4 w-4" />
              Descargar
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56">
            <DropdownMenuGroup>
              <DropdownMenuItem onClick={() => handleDownload('dicom')}>
                Formato DICOM
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleDownload('zip')}>
                Formato ZIP
              </DropdownMenuItem>
            </DropdownMenuGroup>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardFooter>
    </Card>
  );
};

export default DicomViewer;
