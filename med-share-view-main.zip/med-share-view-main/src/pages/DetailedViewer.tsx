
import { useEffect, useRef, useState } from 'react';
import { useParams, useLocation, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import cornerstone from 'cornerstone-core';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { toast } from 'sonner';
import { 
  ZoomIn, 
  ZoomOut,
  RotateCw,
  RotateCcw,
  Move,
  Layers,
  Square,
  Circle,
  Download,
  ChevronLeft
} from 'lucide-react';
import { getFile, downloadDicom } from '@/services/DicomService';

const DetailedViewer = () => {
  const { fileId } = useParams<{ fileId: string }>();
  const location = useLocation();
  const { fileUrl, fileName } = location.state || {};
  const { user } = useAuth();
  
  const viewportRef = useRef<HTMLDivElement>(null);
  const [windowWidth, setWindowWidth] = useState(400);
  const [windowCenter, setWindowCenter] = useState(40);
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [tool, setTool] = useState<'zoom' | 'pan' | 'length' | 'rectangle' | 'circle'>('zoom');
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageInfo, setImageInfo] = useState<any>(null);

  // Inicializar y cargar la imagen
  useEffect(() => {
    if (!viewportRef.current || !fileUrl) return;
    
    const element = viewportRef.current;
    
    try {
      // Asegurar que el elemento esté limpio antes de habilitar
      try {
        cornerstone.disable(element);
      } catch (e) {
        // Ignorar errores si el elemento no estaba habilitado previamente
      }

      // Habilitar el elemento para cornerstone
      cornerstone.enable(element);
      
      // Cargar la imagen
      cornerstone.loadImage(`wadouri:${fileUrl}`).then(image => {
        // Mostrar la imagen en el viewport
        cornerstone.displayImage(element, image);
        
        // Ajustar el tamaño de la ventana inicialmente
        const viewport = cornerstone.getViewport(element);
        setWindowWidth(viewport.voi.windowWidth || 400);
        setWindowCenter(viewport.voi.windowCenter || 40);
        
        // Guardar información de la imagen
        setImageInfo({
          columns: image.columns,
          rows: image.rows,
          windowCenter: image.windowCenter,
          windowWidth: image.windowWidth,
          pixelSpacing: image.rowPixelSpacing && image.columnPixelSpacing ? 
            `${image.rowPixelSpacing.toFixed(2)} x ${image.columnPixelSpacing.toFixed(2)}` : 'N/A',
        });
        
        setImageLoaded(true);
        toast.success('Imagen DICOM cargada correctamente');
      }, error => {
        console.error('Error al cargar la imagen DICOM:', error);
        toast.error('Error al cargar la imagen DICOM');
      });
    } catch (error) {
      console.error('Error en cornerstone:', error);
      toast.error('Error al inicializar el visor DICOM');
    }

    // Limpieza
    return () => {
      try {
        if (element) {
          cornerstone.disable(element);
        }
      } catch (error) {
        console.error('Error al limpiar cornerstone:', error);
      }
    };
  }, [fileUrl]);

  // Actualizar la ventana y nivel
  useEffect(() => {
    if (!imageLoaded || !viewportRef.current) return;
    
    try {
      const element = viewportRef.current;
      const viewport = cornerstone.getViewport(element);
      
      viewport.voi.windowWidth = windowWidth;
      viewport.voi.windowCenter = windowCenter;
      cornerstone.setViewport(element, viewport);
    } catch (error) {
      console.error('Error al ajustar ventana/nivel:', error);
    }
  }, [windowWidth, windowCenter, imageLoaded]);

  // Actualizar el zoom
  const handleZoom = (delta: number) => {
    if (!imageLoaded || !viewportRef.current) return;
    
    try {
      const newZoom = zoom + delta;
      if (newZoom >= 0.25 && newZoom <= 5) {
        setZoom(newZoom);
        
        const element = viewportRef.current;
        const viewport = cornerstone.getViewport(element);
        
        viewport.scale = newZoom;
        cornerstone.setViewport(element, viewport);
      }
    } catch (error) {
      console.error('Error al ajustar zoom:', error);
    }
  };

  // Rotar la imagen
  const handleRotate = (clockwise: boolean) => {
    if (!imageLoaded || !viewportRef.current) return;
    
    try {
      const delta = clockwise ? 90 : -90;
      const newRotation = (rotation + delta) % 360;
      setRotation(newRotation);
      
      const element = viewportRef.current;
      const viewport = cornerstone.getViewport(element);
      
      viewport.rotation = newRotation;
      cornerstone.setViewport(element, viewport);
    } catch (error) {
      console.error('Error al rotar la imagen:', error);
    }
  };

  // Manejar las descargas
  const handleDownload = (format: 'dicom' | 'zip') => {
    if (!fileId) return;
    
    try {
      downloadDicom(fileId, format);
      toast.success(`Descargando ${fileName} en formato ${format === 'dicom' ? 'DICOM' : 'ZIP'}`);
    } catch (error) {
      toast.error('Error al descargar el archivo');
      console.error('Error al descargar:', error);
    }
  };

  return (
    <div className="container mx-auto py-6 px-4">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center gap-2">
          <Link to="/dashboard">
            <Button variant="outline" size="sm">
              <ChevronLeft className="h-4 w-4 mr-1" /> 
              Volver
            </Button>
          </Link>
          <h1 className="text-xl font-bold">
            Visualizador DICOM avanzado: {fileName || ''}
          </h1>
        </div>
        
        <div className="flex gap-2">
          <Button onClick={() => handleDownload('dicom')} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-1" /> 
            DICOM
          </Button>
          <Button onClick={() => handleDownload('zip')} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-1" /> 
            ZIP
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2">
          <div className="bg-black rounded-md overflow-hidden border border-gray-700" style={{ height: 'calc(100vh - 220px)', width: '100%', position: 'relative' }}>
            <div ref={viewportRef} className="dicom-viewport" style={{ height: '100%', width: '100%' }}>
              {!imageLoaded && (
                <div className="flex items-center justify-center h-full text-white">
                  <p>Cargando imagen DICOM...</p>
                </div>
              )}
            </div>
            
            {imageLoaded && imageInfo && (
              <div className="absolute bottom-2 left-2 text-white text-xs bg-black bg-opacity-50 p-2 rounded">
                {`${imageInfo.columns} x ${imageInfo.rows} px • Zoom: ${zoom.toFixed(2)}x • Rotación: ${rotation}°`}
              </div>
            )}
          </div>
          
          <div className="mt-4 flex flex-wrap gap-2 bg-secondary p-2 rounded">
            <Button 
              variant={tool === 'zoom' ? 'default' : 'secondary'} 
              size="sm" 
              onClick={() => setTool('zoom')}
            >
              <ZoomIn className="h-4 w-4 mr-1" />
              Zoom
            </Button>
            <Button 
              variant={tool === 'pan' ? 'default' : 'secondary'} 
              size="sm" 
              onClick={() => setTool('pan')}
            >
              <Move className="h-4 w-4 mr-1" />
              Mover
            </Button>
            <Button 
              variant={tool === 'length' ? 'default' : 'secondary'} 
              size="sm" 
              onClick={() => setTool('length')}
            >
              <Layers className="h-4 w-4 mr-1" />
              Medir
            </Button>
            <Button 
              variant={tool === 'rectangle' ? 'default' : 'secondary'} 
              size="sm" 
              onClick={() => setTool('rectangle')}
            >
              <Square className="h-4 w-4 mr-1" />
              Rectángulo
            </Button>
            <Button 
              variant={tool === 'circle' ? 'default' : 'secondary'} 
              size="sm" 
              onClick={() => setTool('circle')}
            >
              <Circle className="h-4 w-4 mr-1" />
              Círculo
            </Button>
            <Button size="sm" onClick={() => handleZoom(0.1)}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button size="sm" onClick={() => handleZoom(-0.1)}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button size="sm" onClick={() => handleRotate(true)}>
              <RotateCw className="h-4 w-4" />
            </Button>
            <Button size="sm" onClick={() => handleRotate(false)}>
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className="border rounded-md p-4 bg-card">
            <h2 className="text-lg font-medium mb-4">Ajustes de visualización</h2>
            
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Brillo (Centro de ventana): {windowCenter}</label>
                <Slider 
                  value={[windowCenter]} 
                  min={-1024} 
                  max={1024} 
                  step={1}
                  onValueChange={(values) => setWindowCenter(values[0])} 
                />
              </div>

              <div>
                <label className="text-sm font-medium">Contraste (Ancho de ventana): {windowWidth}</label>
                <Slider 
                  value={[windowWidth]} 
                  min={1} 
                  max={2048} 
                  step={1} 
                  onValueChange={(values) => setWindowWidth(values[0])} 
                />
              </div>

              <div>
                <label className="text-sm font-medium">Zoom: {zoom.toFixed(2)}x</label>
                <Slider 
                  value={[zoom]} 
                  min={0.25} 
                  max={5} 
                  step={0.1} 
                  onValueChange={(values) => setZoom(values[0])} 
                />
              </div>

              <div>
                <label className="text-sm font-medium">Rotación: {rotation}°</label>
                <div className="flex gap-2 mt-1">
                  <Button variant="outline" size="sm" onClick={() => handleRotate(false)}>
                    <RotateCcw className="h-4 w-4 mr-1" /> -90°
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleRotate(true)}>
                    <RotateCw className="h-4 w-4 mr-1" /> +90°
                  </Button>
                </div>
              </div>
            </div>
          </div>
          
          {imageInfo && (
            <div className="border rounded-md p-4 bg-card">
              <h2 className="text-lg font-medium mb-4">Información DICOM</h2>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="font-medium">Dimensiones:</span>
                  <span>{imageInfo.columns} x {imageInfo.rows} px</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Espacio entre píxeles:</span>
                  <span>{imageInfo.pixelSpacing}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Centro de ventana:</span>
                  <span>{imageInfo.windowCenter}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-medium">Ancho de ventana:</span>
                  <span>{imageInfo.windowWidth}</span>
                </div>
                {fileName && (
                  <div className="flex justify-between">
                    <span className="font-medium">Nombre del archivo:</span>
                    <span className="truncate max-w-[150px]" title={fileName}>
                      {fileName}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DetailedViewer;
