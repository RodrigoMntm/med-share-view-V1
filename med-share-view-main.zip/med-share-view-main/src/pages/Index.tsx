
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Si el usuario está autenticado, redirigir al dashboard
    if (user) {
      navigate("/dashboard");
    } else {
      // Si no está autenticado, redirigir a la página de login
      navigate("/login");
    }
  }, [user, navigate]);

  return (
    <div className="flex items-center justify-center h-screen">
      <p>Redireccionando...</p>
    </div>
  );
};

export default Index;
