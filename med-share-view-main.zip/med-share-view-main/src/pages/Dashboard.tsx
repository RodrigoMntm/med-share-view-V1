
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import FileUpload from "@/components/FileUpload";
import DicomViewer from "@/components/DicomViewer";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { 
  saveFile, 
  getAllFiles, 
  loadDicomForViewing, 
  extractDicomFromZip, 
  initializeCornerstone,
  saveDicomFilesFromZip,
  getDicomFilesFromZip
} from "@/services/DicomService";
import { Trash2 } from "lucide-react";

interface DicomFile {
  id: string;
  file: File;
  url: string;
  parentZip?: string; // Si el archivo proviene de un ZIP, esto almacenará el ID del ZIP
}

const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [files, setFiles] = useState<DicomFile[]>([]);
  const [selectedFile, setSelectedFile] = useState<DicomFile | null>(null);
  const [loading, setLoading] = useState(true);

  // Inicializar cornerstone
  useEffect(() => {
    try {
      initializeCornerstone();
      setLoading(false);
    } catch (error) {
      console.error('Error al inicializar cornerstone:', error);
      toast.error('Error al inicializar el visualizador DICOM');
    }
  }, []);

  // Redirigir si no hay usuario autenticado
  useEffect(() => {
    if (!user) {
      navigate("/");
    }
  }, [user, navigate]);
  
  // Cargar archivos almacenados
  useEffect(() => {
    const loadFiles = async () => {
      const storedFiles = getAllFiles();
      const loadedFiles: DicomFile[] = [];
      
      for (const [id, file] of Object.entries(storedFiles)) {
        try {
          const url = await loadDicomForViewing(file);
          loadedFiles.push({ id, file, url });
        } catch (error) {
          console.error(`Error al cargar archivo ${id}:`, error);
        }
      }
      
      setFiles(loadedFiles);
      
      // Seleccionar el primer archivo si existe
      if (loadedFiles.length > 0 && !selectedFile) {
        setSelectedFile(loadedFiles[0]);
      }
    };
    
    loadFiles();
  }, []);

  // Manejar la carga de archivos
  const handleFileUpload = async (file: File) => {
    try {
      setLoading(true);
      
      // Procesar archivo según su tipo
      if (file.name.toLowerCase().endsWith('.zip')) {
        await handleZipUpload(file);
      } else {
        await handleDicomUpload(file);
      }
    } catch (error) {
      console.error('Error al procesar el archivo:', error);
      toast.error('Error al procesar el archivo');
    } finally {
      setLoading(false);
    }
  };

  // Manejar la carga de un archivo DICOM individual
  const handleDicomUpload = async (file: File) => {
    const fileId = `${Date.now()}-${file.name}`;
    saveFile(fileId, file);
    
    // Cargar para visualización
    const url = await loadDicomForViewing(file);
    
    // Añadir a la lista de archivos
    const newDicomFile = { id: fileId, file, url };
    setFiles(prevFiles => [...prevFiles, newDicomFile]);
    
    // Seleccionar el archivo recién cargado
    setSelectedFile(newDicomFile);
    
    toast.success(`Archivo ${file.name} procesado correctamente`);
  };

  // Manejar la carga de un archivo ZIP
  const handleZipUpload = async (file: File) => {
    const zipId = `zip-${Date.now()}-${file.name}`;
    const extractedFiles = await extractDicomFromZip(file);
    
    if (extractedFiles.length === 0) {
      toast.error('El archivo ZIP no contiene archivos DICOM válidos');
      return;
    }
    
    // Guardar todos los archivos extraídos
    saveDicomFilesFromZip(zipId, extractedFiles);
    
    // Procesar cada archivo DICOM extraído
    const newDicomFiles: DicomFile[] = [];
    
    for (const dicomFile of extractedFiles) {
      const fileId = `${zipId}-${dicomFile.name}`;
      saveFile(fileId, dicomFile);
      
      // Cargar para visualización
      const url = await loadDicomForViewing(dicomFile);
      
      newDicomFiles.push({ 
        id: fileId, 
        file: dicomFile, 
        url,
        parentZip: zipId
      });
    }
    
    // Añadir todos los nuevos archivos a la lista
    setFiles(prevFiles => [...prevFiles, ...newDicomFiles]);
    
    // Seleccionar el primer archivo extraído
    if (newDicomFiles.length > 0) {
      setSelectedFile(newDicomFiles[0]);
    }
    
    toast.success(`Extraídos ${extractedFiles.length} archivos DICOM de ${file.name}`);
  };

  // Manejar la selección de archivos
  const handleFileSelect = (file: DicomFile) => {
    setSelectedFile(file);
  };

  // Función para eliminar un archivo
  const handleFileDelete = (fileId: string, event: React.MouseEvent) => {
    event.stopPropagation(); // Prevenir que se active la selección del archivo
    
    // Filtrar el archivo eliminado
    const updatedFiles = files.filter(file => file.id !== fileId);
    setFiles(updatedFiles);
    
    // Si el archivo eliminado era el seleccionado, seleccionar otro o ninguno
    if (selectedFile && selectedFile.id === fileId) {
      setSelectedFile(updatedFiles.length > 0 ? updatedFiles[0] : null);
    }
    
    toast.success('Archivo eliminado correctamente');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <p>Cargando...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 px-4">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-primary">DICOM Transfer</h1>
          <p className="text-muted-foreground">
            {user?.role === "doctor" ? "Portal del Doctor" : "Portal del Paciente"}
          </p>
        </div>
        
        <div className="flex items-center">
          <span className="mr-4">Usuario: <b>{user?.username}</b></span>
          <Button variant="outline" onClick={() => {
            logout();
            navigate("/");
          }}>
            Cerrar sesión
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1 space-y-4">
          <div className="space-y-2">
            <h2 className="text-xl font-medium">Cargar imagen DICOM</h2>
            <FileUpload onFileUpload={handleFileUpload} />
          </div>

          <div className="mt-6">
            <h3 className="text-lg font-medium mb-2">Archivos disponibles</h3>
            {files.length > 0 ? (
              <ul className="space-y-2">
                {files.map((file) => (
                  <li 
                    key={file.id}
                    className={`p-2 rounded-md cursor-pointer relative group ${
                      selectedFile?.id === file.id 
                        ? "bg-primary text-white" 
                        : "bg-secondary hover:bg-secondary/80"
                    }`}
                    onClick={() => handleFileSelect(file)}
                  >
                    <div className="flex justify-between items-center">
                      <span className="truncate pr-8">
                        {file.parentZip && '└─ '}{file.file.name}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="absolute right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={(e) => handleFileDelete(file.id, e)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No hay archivos cargados</p>
            )}
          </div>
        </div>

        <div className="md:col-span-2">
          {selectedFile ? (
            <DicomViewer 
              fileUrl={selectedFile.url} 
              fileId={selectedFile.id}
              fileName={selectedFile.file.name}
            />
          ) : (
            <div className="flex items-center justify-center h-full border rounded-lg p-8">
              <p className="text-muted-foreground">
                Seleccione o cargue un archivo DICOM para visualizarlo
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
