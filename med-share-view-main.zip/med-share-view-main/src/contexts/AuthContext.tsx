
import React, { createContext, useContext, useState, ReactNode } from "react";

export type UserRole = "doctor" | "patient";

interface User {
  username: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

const PREDEFINED_USERS = {
  "doctor1": { password: "doc123", role: "doctor" as UserRole },
  "patient1": { password: "pat123", role: "patient" as UserRole },
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  const login = (username: string, password: string): boolean => {
    const userDetails = PREDEFINED_USERS[username as keyof typeof PREDEFINED_USERS];
    
    if (userDetails && userDetails.password === password) {
      setUser({ username, role: userDetails.role });
      return true;
    }
    
    return false;
  };

  const logout = () => {
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
