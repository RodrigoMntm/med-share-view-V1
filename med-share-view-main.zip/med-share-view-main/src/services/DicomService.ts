
import cornerstoneWADOImageLoader from 'cornerstone-wado-image-loader';
import cornerstone from 'cornerstone-core';
import dicomParser from 'dicom-parser';
import JSZip from 'jszip';

// Mock storage para los archivos (en una aplicación real, esto sería un backend)
const fileStorage: Record<string, File> = {};
const zipDicomFiles: Record<string, File[]> = {}; // Almacenamiento para archivos DICOM extraídos de ZIPs

// Inicializa cornerstone
export function initializeCornerstone() {
  // Configurar el cargador de imágenes WADO
  cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
  cornerstoneWADOImageLoader.external.dicomParser = dicomParser;
  
  // Registrar el decodificador de imágenes
  cornerstoneWADOImageLoader.webWorkerManager.initialize({
    maxWebWorkers: navigator.hardwareConcurrency || 1,
    startWebWorkersOnDemand: true,
    taskConfiguration: {
      decodeTask: {
        initializeCodecsOnStartup: true,
      },
    },
  });
  
  // Habilitar el uso de File y Blob URLs
  cornerstoneWADOImageLoader.wadouri.fileManager.add = function(file) {
    const fileUrl = URL.createObjectURL(file);
    return fileUrl;
  };
  
  // Configurar el parseador DICOM
  cornerstoneWADOImageLoader.initialized = true;
}

// Guardar un archivo
export function saveFile(fileId: string, file: File): void {
  fileStorage[fileId] = file;
}

// Guardar múltiples archivos DICOM de un ZIP
export function saveDicomFilesFromZip(zipId: string, files: File[]): void {
  zipDicomFiles[zipId] = files;
}

// Obtener archivos DICOM de un ZIP
export function getDicomFilesFromZip(zipId: string): File[] {
  return zipDicomFiles[zipId] || [];
}

// Obtener un archivo
export function getFile(fileId: string): File | undefined {
  return fileStorage[fileId];
}

// Obtener todos los archivos
export function getAllFiles(): Record<string, File> {
  return { ...fileStorage };
}

// Cargar un archivo DICOM para visualización
export async function loadDicomForViewing(file: File): Promise<string> {
  try {
    // Registrar el archivo con cornerstone
    const fileUrl = cornerstoneWADOImageLoader.wadouri.fileManager.add(file);
    console.log('URL creada para visualización DICOM:', fileUrl);
    return fileUrl;
  } catch (error) {
    console.error('Error al crear URL para visualización DICOM:', error);
    // Fallback a URL.createObjectURL si el método anterior falla
    return URL.createObjectURL(file);
  }
}

// Extraer todos los archivos DICOM de un ZIP
export async function extractDicomFromZip(zipFile: File): Promise<File[]> {
  try {
    const zip = await JSZip.loadAsync(zipFile);
    const dicomFiles: File[] = [];
    
    // Procesar todos los archivos del ZIP
    const filePromises = Object.keys(zip.files).map(async (filename) => {
      // Solo procesar archivos (no directorios)
      if (!zip.files[filename].dir) {
        // Verificar si es un archivo DICOM por extensión o intento de parse
        const isDicom = filename.toLowerCase().endsWith('.dcm') || 
                        filename.indexOf('.') === -1; // Sin extensión (posiblemente DICOM)
        
        if (isDicom) {
          try {
            const blob = await zip.files[filename].async('blob');
            const dicomFile = new File([blob], filename.split('/').pop() || filename, { type: 'application/dicom' });
            dicomFiles.push(dicomFile);
            console.log('Archivo DICOM extraído del ZIP:', filename);
          } catch (err) {
            console.warn(`Error al extraer archivo ${filename}:`, err);
          }
        }
      }
    });
    
    await Promise.all(filePromises);
    
    console.log(`Extraídos ${dicomFiles.length} archivos DICOM del ZIP`);
    return dicomFiles;
  } catch (error) {
    console.error('Error extracting DICOM from ZIP:', error);
    return [];
  }
}

// Función para descargar un archivo DICOM
export function downloadDicom(fileId: string, format: 'dicom' | 'zip') {
  const file = getFile(fileId);
  
  if (!file) {
    throw new Error('Archivo no encontrado');
  }
  
  if (format === 'dicom' || (file.name.toLowerCase().endsWith('.dcm') && format === 'zip')) {
    // Descarga directa para archivos DICOM o si ya es un ZIP
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  } else if (format === 'zip') {
    // Crear un archivo ZIP para la descarga
    createAndDownloadZip(file);
  }
}

// Función para crear y descargar un archivo ZIP
async function createAndDownloadZip(file: File) {
  const zip = new JSZip();
  
  // Agregar el archivo al ZIP
  zip.file(file.name, file);
  
  // Generar el ZIP
  const content = await zip.generateAsync({ type: 'blob' });
  
  // Descargar el ZIP
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${file.name.split('.')[0]}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
